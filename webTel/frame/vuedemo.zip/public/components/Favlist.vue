<template>
    <div>
        <span v-for="n in 10">div{{n}}</span>
    </div>
</template>

<script>
    export default {
        data(){
            return {
                msg: 'Hello World!'
            }
        }
    }
</script>

<style>
    html{
        background: red;
    }
</style>