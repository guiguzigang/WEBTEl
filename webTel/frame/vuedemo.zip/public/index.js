/**
 * Created by xiajun on 2017/3/30.
 */
import Vue from 'vue'
import Favlist from './components/Favlist'

new Vue({
    el: '#app',
    components: { Favlist }
})
